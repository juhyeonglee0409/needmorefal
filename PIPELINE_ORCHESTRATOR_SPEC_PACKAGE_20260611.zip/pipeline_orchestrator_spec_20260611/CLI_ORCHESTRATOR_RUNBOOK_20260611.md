# CLI Orchestrator Runbook — Charles → Arthur → Case Package

목적: CLI 오케스트레이터가 구비바/김달수 같은 케이스 패키지에서 공개 웹 통계·코호트 데이터를 수집할 때 따라야 할 순서.

## 0. 입력

```text
case_package_dir       예: 구비바_CASE_PACKAGE_v3_20260611/
case_id                예: gubiba
cohort_spec            data/cohort/specs/구비바_§4_cohort_spec_v2_20260610.json
target_batch_plan      TargetBatchPlan JSON
profile_path           선택. operator가 승인한 browser profile JSON
run_root               runs/{case_id}/{run_id}/
```

## 1. Run directory 계약

```text
runs/{case_id}/{run_id}/
  00_inputs/
    target_batch_plan.json
    cohort_spec.json
    profile_summary.json          # 값 없음. 제공 여부/이름만.
  10_charles/
    {target_id}.scout_report.json
    {target_id}.protocol.json
    {target_id}.scout_raw/         # --save-raw 시
  20_review/
    {target_id}.review_note.md
    collect_directives/
      {target_id}.CollectDirective.json
  30_arthur_inspect/
    {target_id}.InspectResult.json
  40_arthur_collect/
    {target_id}/
      _meta.json
      items.jsonl
      combined.json
      raw/
    {target_id}.CollectionResult.json
  50_ingest_candidates/
    EvidencePackage_patch.json
    AbsenceInventory_patch.json
    DisclosureLog_patch.json
  RUN_MANIFEST.json
```

## 2. Phase A — target plan 검증

오케스트레이터는 먼저 target별로 아래를 확인한다.

```text
target_id 존재
target_url은 http/https
cohort_type은 main_general_game / aux_virtual / follower_rank 등 canonical 값
required_columns 존재
approved_scope 후보 존재
profile_required 기본값은 false
public/private disclosure 기본 red
```

URL이 localhost/private IP/file path면 중단한다. Arthur도 stop하지만, 오케스트레이터가 먼저 막는 게 좋다.

## 3. Phase B — Charles 진단

### 기본 진단

```bash
scouter "$TARGET_URL" \
  --json \
  --out "$RUN/10_charles/${TARGET_ID}.scout_report.json" \
  --max-requests 20 \
  --max-runtime 60
```

### profile-aware Engage 진단

checkpoint/429/login/access boundary가 있거나 target_batch_plan이 profile을 요구하면:

```bash
scouter "$TARGET_URL" \
  --engage \
  --transport curl_cffi \
  --profile "$PROFILE_PATH" \
  --json \
  --save-raw \
  --out "$RUN/10_charles/${TARGET_ID}.scout_report.json" \
  --out-dir "$RUN/10_charles/${TARGET_ID}.raw" \
  --max-requests 30 \
  --max-runtime 120
```

주의: profile 값은 report/protocol에 저장하지 않는다. profile file 자체도 case package에 넣지 않는다.

## 4. Phase C — protocol 추출

scouter report 전체가 아니라 `protocol` 섹션만 별도로 저장한다.

```bash
python - <<'PY'
import json, sys
src, dst = sys.argv[1], sys.argv[2]
data = json.load(open(src, encoding='utf-8'))
protocol = data.get('protocol')
if not isinstance(protocol, dict):
    raise SystemExit('protocol missing')
json.dump(protocol, open(dst,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
PY "$SCOUT_REPORT" "$PROTOCOL_JSON"
```

이렇게 해야 Arthur verification이 `protocol` 정본 입력으로 처리된다.

## 5. Phase D — review gate

오케스트레이터는 protocol의 아래 값을 확인한다.

```text
best_path
pre_check.robots_status
pre_check.gate_status
pre_check.login_required
pre_check.terms_flag
pre_check.risk_level
transport
profile_required
diagnostic_findings
```

### 자동 collect 금지 조건

아래 조건이면 collect directive를 만들지 않고 operator question을 남긴다.

```text
best_path = manual_review
pre_check.gate_status = restricted / not_attempted / phase2_error
pre_check.login_required = true and profile 없음
profile_required = true and profile 없음
pre_check.risk_level = high and operator 승인 없음
target-specific bypass가 필요한 경우
approved_scope를 만들 수 없는 경우
```

## 6. Phase E — Arthur inspect

inspect는 collect 전 지형 확인이다.

```bash
arthur inspect "$DIRECTIVE_OR_PROTOCOL" \
  --out "$RUN/30_arthur_inspect/${TARGET_ID}.InspectResult.json" \
  --transport "$TRANSPORT" \
  --max-requests 10
```

profile이 있으면:

```bash
arthur inspect "$DIRECTIVE_OR_PROTOCOL" \
  --profile "$PROFILE_PATH" \
  --transport curl_cffi \
  --out "$RUN/30_arthur_inspect/${TARGET_ID}.InspectResult.json" \
  --max-requests 10
```

inspect 결과의 `operator_questions`가 비어 있지 않으면 collect 전에 사람에게 보여준다.

## 7. Phase F — CollectDirective 생성

CollectDirective는 Hosea/operator 승인 범위를 기계가 읽게 만든 것이다.

필수 원칙:

```text
approved = true는 사람 승인 후에만.
approved_scope.allowed_domains와 path_prefixes를 좁게 잡는다.
field_policy.exclude/mask로 개인정보/토큰/이메일/민감값을 제거한다.
raw_policy.save_raw는 case policy에 맞춘다.
boundary_policy는 proceed/record 중심. stop 조건은 명시한다.
```

## 8. Phase G — Arthur collect

```bash
arthur collect "$COLLECT_DIRECTIVE" \
  --out-dir "$RUN/40_arthur_collect/${TARGET_ID}" \
  --transport "$TRANSPORT" \
  --max-requests "$MAX_REQUESTS" \
  --max-pages "$MAX_PAGES" \
  --max-items "$MAX_ITEMS" \
  --save-raw
```

profile이 있으면 `--profile "$PROFILE_PATH"` 추가.

## 9. Phase H — 결과 판정 금지, ingest 후보 생성

오케스트레이터는 Arthur 결과를 성공/실패로 해석하지 않는다. 대신 아래 후보 패치를 만든다.

```text
EvidencePackage_patch.json
AbsenceInventory_patch.json
DisclosureLog_patch.json
```

Arthur verification이 `not_verifiable`이어도 버리지 않는다. 그 사실을 EvidencePackage와 AbsenceInventory에 남긴다.

## 10. Phase I — Case Package 반영

수집 결과는 바로 CaseResult ready로 승격하지 않는다.

```text
CollectionResult → EvidencePackage patch
Absences → AbsenceInventory patch
boundary_signals → EvidencePackage + DisclosureLog
field_coverage → §4/§5 작업 노트
verification.status → data_quality note
```

최종 CaseResult 승격은 §4 final cohort와 §5 진단 후 진행한다.
