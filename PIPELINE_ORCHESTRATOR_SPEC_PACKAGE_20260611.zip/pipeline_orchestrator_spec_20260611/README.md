# Pipeline Orchestrator Spec Package — 2026-06-11

이 패키지는 현재 업로드된 두 파이프라인 도구를 확인한 뒤, CLI 오케스트레이터가 Charles/CrawlScouter와 Arthur를 어떻게 호출할지 정리한 작업물이다.

## 파일

- `PIPELINE_TOOL_REVIEW_Charles_Arthur_20260611.md` — 도구 확인 요약
- `CLI_ORCHESTRATOR_RUNBOOK_20260611.md` — 실행 순서/파일 구조/게이트
- `CLI_ORCHESTRATOR_SPEC_TABLE_20260611.csv` — 오케스트레이터 명세표
- `CLI_ORCHESTRATOR_PROMPTS_20260611.md` — Hosea/Charles/Arthur/Operator 프롬프트 초안
- `TargetBatchPlan_template_gubiba_cohort_v3.json` — 구비바 §4 코호트 수집 target plan 템플릿
- `CollectDirective_template_gubiba_cohort_v3.json` — Arthur용 승인 지시 템플릿

## 다음 단계

1. 실제 통계 출처 URL을 TargetBatchPlan에 채운다.
2. Charles Phase 1 진단을 실행한다.
3. boundary/login/profile 신호가 있으면 operator review를 거친다.
4. ExecutionProtocol만 추출한다.
5. Arthur inspect를 실행한다.
6. CollectDirective를 사람이 승인한다.
7. Arthur collect를 실행한다.
8. EvidencePackage / AbsenceInventory / DisclosureLog patch 후보를 만든다.
