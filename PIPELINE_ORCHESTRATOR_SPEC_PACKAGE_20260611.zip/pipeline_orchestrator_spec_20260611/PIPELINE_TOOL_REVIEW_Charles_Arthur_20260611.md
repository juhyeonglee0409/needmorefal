# Pipeline Tool Review — Charles/CrawlScouter v0.10.0 + Arthur v0.6

작성일: 2026-06-11  
목적: 현재 보유한 크진단기(Charles/CrawlScouter)와 크롤러(Arthur)를 확인하고, CLI 오케스트레이터가 실행할 명세와 프롬프트를 정리한다.

## 1. 결론

현재 도구 조합은 최신 MASTER v2 / M7.1의 파이프라인에 충분히 맞는다.

```text
Charles / CrawlScouter
= 진단기. URL을 보고 ScoutReport + ExecutionProtocol을 만든다.

Arthur
= 크롤러. Charles가 만든 ExecutionProtocol 또는 Hosea가 승인한 CollectDirective를 실행한다.

CLI Orchestrator / Hosea
= 사람 승인과 실행 순서를 관리한다.
  판단·해석·저장정본화는 직접 하지 않고, 경계/승인/파일 위치/다음 도구 호출을 관리한다.
```

핵심 운영 원칙:

```text
Charles가 본다.
Hosea/CLI Orchestrator가 승인 범위로 접는다.
Arthur가 실행한다.
Pearson/Susan/ND가 나중에 저장·검증·부재 판단한다.
```

## 2. 확인된 도구 버전

| 도구 | 버전 | 역할 | 주요 입출력 |
|---|---:|---|---|
| CrawlScouter / Charles | 0.10.0 | 사전 진단, boundary signal, API/sitemap/RSC 후보, ExecutionProtocol 생성 | ScoutReport JSON, ExecutionProtocol JSON |
| Arthur | 0.6 | ExecutionProtocol/CollectDirective 실행, inspect/collect, raw/structured/meta 보존 | InspectResult JSON, CollectionResult JSON |

## 3. Charles / CrawlScouter v0.10.0 확인 요약

### CLI

```bash
scouter https://target.example --json --out report.json
scouter https://target.example --engage --transport curl_cffi --profile profile.json --json --out report.json
scouter https://target.example --engage --transport curl_cffi --profile profile.json --save-raw --out-dir run_output
```

주요 옵션:

```text
--transport httpx|curl_cffi|playwright
--profile profile.json
--save-raw
--max-requests N
--max-runtime SECONDS
--protocol / --no-protocol
--agent-prompt
--out / --out-dir / --force
```

### MCP

```text
scout_site(url)      -> human-readable report
scout_json(url)      -> full JSON scout report
scout_protocol(url)  -> ExecutionProtocol JSON
```

### 출력 핵심

`scouter --json`은 최상위에 `protocol`을 포함할 수 있다. 이 protocol은 Arthur가 직접 먹을 수 있는 ExecutionProtocol이다.

ExecutionProtocol 핵심 필드:

```text
version
generated_at
target_url
best_path
best_path_trace
pre_check
connection_test
collection_plan
storage
verification
agent_prompt
notes
transport
profile_required
profile_summary
rsc_payload_candidates
diagnostic_findings
```

### v0.10.0에서 중요한 점

- `diagnostic_findings`가 생겼다. API/sitemap/RSC의 진단 출처를 Arthur/Pearson 쪽으로 넘기기 좋다.
- `profile_cleared`가 robots/login/terms 위험을 덮어쓰지 않도록 risk ordering이 보강됐다.
- profile/cookie/header 값은 report/protocol에 저장하지 않고 이름과 제공 여부만 남긴다.
- Phase 1에서 checkpoint/429/access boundary가 나오면, operator가 승인한 profile + curl_cffi transport로 Phase 2를 수행할 수 있다.
- RSC payload 후보가 발견되면 `best_path = rsc_payload`, `transport = curl_cffi`, `profile_required = true` 처방이 가능하다.

## 4. Arthur v0.6 확인 요약

### CLI

```bash
arthur inspect protocol.json --out inspect.json
arthur collect protocol.json --out-dir run_output
arthur protocol.json
arthur protocol.json --dry-run
cat protocol.json | arthur -
```

주요 옵션:

```text
--ua
--delay
--max-items
--max-pages
--max-requests
--max-runtime
--transport httpx|playwright|curl_cffi
--profile
--save-raw
--out
--out-dir
--force
--verbose
```

### MCP

```text
inspect_data(protocol, max_requests=10, transport="httpx", profile="")
collect_data(protocol, out_dir="", max_requests=200, max_pages=50, max_items=1000, save_raw=false, transport="httpx", profile="", return_json=true)
```

### 입력 형태

Arthur는 세 형태를 받는다.

| 형태 | 설명 | 검증 상태 |
|---|---|---|
| protocol | Charles의 ExecutionProtocol 단독 | 정본 입력 |
| scout_report | scouter --json 전체. 최상위 `protocol` 포함 | 수집은 가능하나 not_verifiable 처리 |
| compact | MCP 텍스트 리포트 기반 JSON | 수집은 가능하나 not_verifiable 처리 |
| CollectDirective | Hosea/CLI가 protocol에 승인 범위와 field policy를 입힌 지시 | 정본 입력 |

자동화에는 **protocol 단독 또는 CollectDirective**를 써야 한다. scout_report/compact는 사람이 읽을 수는 있지만, verification은 강제로 `not_verifiable`이 된다.

### best_path

```text
requests
api_direct
rsc_payload
sitemap_first
playwright
manual_review
```

`manual_review`는 실행하지 않고 기록만 남긴다.

### 출력 핵심

Arthur의 `CollectionResult`는 단순 수집 결과가 아니라 다음을 함께 보존한다.

```text
items
absences
field_coverage
verification
execution
boundary_signals
policy_trace
artifacts
session_profile
protocol_ref
storage_hint
```

### v0.6에서 중요한 점

- `CollectDirective`를 지원한다.
- profile/login-required guard가 있다.
- private network target은 기본 stop이다.
- `inspect_data` MCP가 추가됐다.
- `protocol_ref`에 protocol hash, directive hash, diagnostic findings가 들어간다.
- field_policy로 include/exclude/mask가 가능하다.
- raw_policy로 save_raw를 강제할 수 있다.

## 5. 테스트 확인 상태

| 도구 | 테스트 | 결과 |
|---|---|---|
| CrawlScouter | `tests/test_pipeline_contract_v0_10.py` | 11 PASS / 0 FAIL |
| Arthur | `tests/test_pipeline_contract_v0_6.py` | 현재 컨테이너에 `protego`가 없어 중간 중단. 중단 전 5 PASS 확인 |

Arthur 테스트 중단 사유:

```text
ModuleNotFoundError: No module named 'protego'
```

실행 환경 준비 시 최소 설치:

```bash
pip install -e /path/to/CrawlScouter_v0.10.0_pipeline_contract
pip install -e /path/to/Arthur_v0.6_pipeline_contract
# Arthur에는 protego, httpx, brotli, zstandard, selectolax 필요
# Scouter에는 playwright가 기본 dependency에 포함됨
```

## 6. 최신 MASTER/M7.1과의 정합성

현재 도구는 MASTER v2 M7.1의 핵심 객체와 연결 가능하다.

| MASTER 객체 | 어느 도구가 채우는가 | 매핑 |
|---|---|---|
| EvidencePackage | Charles + Arthur | source_url, raw_path, response_hash, boundary_signal, fetched_at |
| AbsenceInventory | Charles + Arthur | charles_not_found / arthur_collection_failed / target_absent / undetermined |
| DisclosureLog | CLI/Hosea | proposed_tag/final_tag/reason |
| CaseResult | 하류 통합 | Arthur CollectionResult + Pearson/Susan 판단 후 |
| PortfolioRow | Bridge | CaseResult ready 후 |
| PublicDemoRow | 별도 생성 | 실제 client row redaction이 아니라 synthetic/public-safe 객체 |

## 7. 즉시 보강할 점

1. CLI 오케스트레이터는 `CollectDirective`를 기본 입력으로 생성해야 한다.
2. Charles의 `protocol` 섹션만 추출해 정본 프로토콜로 보존해야 한다.
3. `scouter --json 전체`를 Arthur에 직접 넣는 것은 지양한다. 가능하지만 not_verifiable이다.
4. inspect 후 collect 전에는 항상 operator approval step을 둔다.
5. 모든 run은 `run_id`, `case_id`, `target_id`, `protocol_hash`, `directive_hash`를 남긴다.
6. Arthur 실행 환경에는 `protego`가 설치되어야 한다.
