# 구비바 Step 1 §4 코호트 구축 패키지

작성일: 2026-06-10

## 포함 파일

1. `구비바_§4_cohort_spec_v2_20260610.json` — 코호트 구축 machine-readable spec
2. `구비바_§4_코호트_방법론_v2_20260610.md` — 사람이 읽는 §4 방법론 문서
3. `구비바_§4_column_contract_v2_20260610.csv` — 크롤러/스크래퍼 컬럼 계약
4. `구비바_§4_Charles_진단요청_v2_20260610.md` — Charles에게 줄 진단 요청
5. `구비바_§4_Arthur_ExecutionProtocol_v2_TEMPLATE_20260610.json` — Arthur ExecutionProtocol 템플릿
6. `구비바_project_step1_20260610.json` — Step 1 결정 반영 project.json

## 결정

- 주 코호트: 종합게임
- 보조 코호트: 버추얼
- 다음 작업: Charles 진단 → Arthur 수집 → §4 final cohort → §5 진단
